from openpyxl import load_workbook
import os


# -------------------------------------------------
# Helpers
# -------------------------------------------------
def tex_escape(s):
    if not s:
        return ""
    s = str(s)
    return (
        s.replace("\\", "\\textbackslash{}")
         .replace("&", "\\&")
         .replace("%", "\\%")
         .replace("_", "\\_")
    )


def classify_row(variant, requirement, description):
    v = (variant or "").lower()
    r = (requirement or "").lower()
    d = (description or "").lower()

    if r == "required":
        return "\\Required"

    if any(k in (v + d) for k in ["fw", "firmware"]):
        return "\\Firmware"

    return "\\Other"


# -------------------------------------------------
# Main
# -------------------------------------------------
def main():
    # -----------------------------
    # TABLE TYPE SELECTION
    # -----------------------------
    print("Select output type:")
    print("1 - MEtable")
    print("2 - OrderingTable")
    print("3 - RelatedProducts")
    choice = input("Choice (1/2/3): ").strip()

    if choice == "1":
        mode = "MEtable"
    elif choice == "2":
        mode = "OrderingTable"
    elif choice == "3":
        mode = "RelatedProducts"
    else:
        print("Invalid choice.")
        return

    # -----------------------------
    # FILE INPUT
    # -----------------------------
    name = input("Excel file name (without .xlsx): ").strip()
    if not name.lower().endswith(".xlsx"):
        name += ".xlsx"

    if not os.path.exists(name):
        print("File not found.")
        return

    wb = load_workbook(name)
    ws = wb.active

    out = os.path.splitext(name)[0] + ".tex"
    lines = []

    # =========================================================
    # RELATED PRODUCTS
    # =========================================================
    if mode == "RelatedProducts":
        lines.append(r"\RelatedProducts{")

        header_row = next(ws.iter_rows(min_row=1, max_row=1))
        ncols = sum(1 for c in header_row if c.value is not None)

        for row in ws.iter_rows(min_row=2):
            cells = row[:ncols]
            if all(cell.value is None for cell in cells):
                continue

            row_tex = []
            for cell in cells:
                if cell.value is None:
                    row_tex.append("")
                elif cell.hyperlink:
                    row_tex.append(
                        f"\\href{{{cell.hyperlink.target}}}{{{tex_escape(cell.value)}}}"
                    )
                else:
                    row_tex.append(tex_escape(cell.value))

            lines.append("  " + " & ".join(row_tex) + r" \\ \hline")

        if lines[-1].endswith(r"\hline"):
            lines[-1] = lines[-1].replace(r" \\ \hline", "")

        lines.append("}")

    # =========================================================
    # METABLE  ✅ merged cells → bold
    # =========================================================
    elif mode == "MEtable":
        header_cells = next(ws.iter_rows(min_row=1, max_row=1))
        ncols = sum(1 for c in header_cells if c.value is not None)
        col_spec = "|" + "|".join(["X"] * ncols) + "|"

        lines.append(f"\\begin{{MEtable}}{{{col_spec}}}")

        header = " & ".join(
            f"\\HS\\highlight{{{tex_escape(c.value)}}}"
            for c in header_cells[:ncols]
        )
        lines.append(f"{header} \\\\ \\hline")

        for row in ws.iter_rows(min_row=2):
            cells = row[:ncols]
            c1 = cells[0]

            # FULL-WIDTH MERGED CELL → SECTION (BOLD)
            is_section = False
            for merged in ws.merged_cells.ranges:
                if (
                    merged.min_row == c1.row
                    and merged.min_col == 1
                    and (merged.max_col - merged.min_col + 1) == ncols
                ):
                    title = tex_escape(c1.value)
                    lines.append(
                        f"\\multicolumn{{{ncols}}}{{|X|}}{{\\textbf{{{title}}}}} \\\\ \\hline"
                    )
                    is_section = True
                    break

            if is_section:
                continue

            row_tex = []
            for cell in cells:
                if cell.hyperlink:
                    row_tex.append(
                        f"\\href{{{cell.hyperlink.target}}}{{{tex_escape(cell.value)}}}"
                    )
                else:
                    row_tex.append(tex_escape(cell.value))

            lines.append(" & ".join(row_tex) + " \\\\ \\hline")

        lines.append("\\end{MEtable}")

    # =========================================================
    # ORDERINGTABLE  (semântico)
    # =========================================================
    else:
        lines.append("\\begin{OrderingTable}{|X|X|X|X|}")
        lines.append("% -------------------------------------------------")
        lines.append("\\Header")
        lines.append("{Variant Name}")
        lines.append("{Requirement}")
        lines.append("{Description}")
        lines.append("{Options / Single choice}")
        lines.append("")

        for row in ws.iter_rows(min_row=2, values_only=True):
            if all(v is None for v in row):
                continue

            variant, requirement, description, options = row
            cmd = classify_row(variant, requirement, description)

            lines.append(cmd)
            lines.append(f"{{{tex_escape(variant)}}}")
            lines.append(f"{{{tex_escape(requirement)}}}")
            lines.append(f"{{{tex_escape(description)}}}")
            lines.append(f"{{{tex_escape(options)}}}")
            lines.append("")

        lines.append("% -------------------------------------------------")
        lines.append("\\end{OrderingTable}")

    # -----------------------------
    # WRITE FILE
    # -----------------------------
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"Generated: {out}")


if __name__ == "__main__":
    main()
